<template>
    <div>
      <h1 align="center">学生管理系统</h1>
      <hr class="hr0"/>
      <el-form :inline="true" :model="searchForm" size="small">
        <el-form-item label="姓名">
          <el-input v-model="searchForm.name" placeholder="姓名" clearable></el-input>
        </el-form-item>

        <el-form-item label="年龄">
          <el-select
              size="small"
              style="width: 100px"
              v-model="searchForm.age"
              placeholder="请选择"
              clearable>
            <el-option
                v-for="i in ages"
                :key="i"
                :label="i"
                :value="i">
            </el-option>
          </el-select>
        </el-form-item>

        <el-form-item label="性别">
          <el-select v-model="searchForm.sex" placeholder="性别" clearable>
            <el-option label="男" value="男"></el-option>
            <el-option label="女" value="女"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item label="入学日期" clearable>
          <el-date-picker
              v-model="searchForm.entryDate"
              value-format="yyyy-MM-dd"
              type="date"
              placeholder="选择日期"
              clearable
              :editable="false">
          </el-date-picker>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="searchStudent()" icon="el-icon-search">搜索</el-button>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="create()">注册学生</el-button>
        </el-form-item>
      </el-form>

      <el-table :data="students" style="width: 100%">
        <!--列-->
        <el-table-column prop="id" label="编号"></el-table-column>
        <el-table-column prop="name" label="姓名"></el-table-column>
        <el-table-column prop="age" label="年龄"></el-table-column>
        <el-table-column prop="sex" label="性别"></el-table-column>
        <el-table-column prop="address" label="地址"></el-table-column>
        <el-table-column prop="entryDate" label="入学日期"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="primary" size="mini" @click="editStudent(scope.row)">编辑</el-button>
            <el-button type="danger" size="mini" @click="deleteStudent(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <br/>
      <br/>

      <!--分页-->
      <el-pagination
          background
          :total="total"
          :page-size="queryDto.pageSize"
          :current-page="queryDto.pageNo"
          layout="sizes,jumper,prev,pager,next,->,total"
          :page-sizes="[5,10,15,20]"
          @current-change="currentChange"
          @size-change="sizeChange">
      </el-pagination>

      <!--弹出编辑框-->
      <el-dialog
          :title="operate"
          :visible.sync="dialogVisible"
          width="30%"
          :before-close="handleClose">
        <el-form :model="studentForm" class="demo-form-inline" label-width="70px">
          <el-form-item label="姓名">
            <el-input v-model="studentForm.name" placeholder="姓名" style="width: 100%" clearable></el-input>
          </el-form-item>
          <el-form-item label="年龄">
            <el-select
                size="small"
                style="width: 100%"
                v-model="studentForm.age"
                placeholder="请选择年龄"
                clearable>
              <el-option
                  v-for="i in ages"
                  :key="i"
                  :label="i"
                  :value="i">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="性别" >
            <el-select v-model="studentForm.sex" placeholder="性别" style="width: 100%" clearable>
              <el-option label="男" value="男"></el-option>
              <el-option label="女" value="女"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="地址">
            <el-input v-model="studentForm.address" placeholder="地址" clearable></el-input>
          </el-form-item>
          <el-form-item label="入学日期" clearable>
            <el-date-picker
                v-model="studentForm.entryDate"
                value-format="yyyy-MM-dd"
                type="date"
                placeholder="选择日期"
                style="width: 100%"
                :editable="false">
            </el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="operateStudent()" size="small">{{operate}}</el-button>
          </el-form-item>
        </el-form>

      </el-dialog>

    </div>
</template>

import axios from '../utils/axios'
<script>
import axios from "@/utils/myAxios";

export default {
  data(){
    return{
      students:[],
      dialogVisible:false,
      studentForm:{
        name:'',
        age:'',
        sex:'',
        address:'',
        entryDate:''
      },
      searchForm:{
        name:'',
        age:'',
        sex:'',
        entryDate:''
      },
      ages:[],
      operate:'注册学生',
      total: 0,
      queryDto: {
        pageNo: 1,
        pageSize: 5
      }
    }
  },
  //页面加载后执行
  mounted() {
    this.findAll(this.queryDto.pageNo,this.queryDto.pageSize);
    for (let i=15;i<=30;i++){
      this.ages.push(i);
    }
  },
  methods:{
    //查所有
    async findAll(pageNo,pageSize){
      const url=`/students/all?pageNo=`+pageNo+`&pageSize=`+pageSize;
      const resp = await axios.get(url);
      this.students=resp.data.data;
      this.total=resp.data.total;
    },

    //新增学生
    create(){
      this.studentForm={},
      this.operate='注册学生';
      this.dialogVisible=true;
    },

    //编辑学生
    editStudent(row){
      this.operate='更新学生';
      this.studentForm=row;
      this.dialogVisible=true;
    },

    //注册或者编辑学生
    operateStudent(){
      const operate = this.operate;
      console.log(operate)
      if(operate==='注册学生'){
        axios.post('/students/add',this.studentForm).then((resp)=>{
          if(resp.data.code===200){
            this.dialogVisible=false;
            this.$message.success('注册学生信息成功');
            this.findAll(this.queryDto.pageNo,this.queryDto.pageSize);
          }
        })
        return;
      }
      //另一种情况就是更新学生数据
      axios.post('/students/edit',this.studentForm).then((resp)=>{
        if(resp.data.code===200){
          this.dialogVisible=false;
          this.$message.success('更新学生信息成功');
          this.findAll(this.queryDto.pageNo,this.queryDto.pageSize);
        }
      })
    },

    //删除学生
    deleteStudent(row){
      this.$confirm("此操作将不可恢复, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      }).then(()=>{
        axios.delete(`/students/delete?id=${row.id}`).then((resp)=>{
          if(resp.data.code===200){
            this.$message.success('删除学生信息成功');
            this.findAll(this.queryDto.pageNo,this.queryDto.pageSize);
          }
        })
      })
    },

    //关闭
    handleClose() {
      this.dialogVisible=false;
    },

    //搜索
    searchStudent(){
      axios.get('/students/search',{params:{
            name:this.searchForm.name,
            sex:this.searchForm.sex,
            entryDate:this.searchForm.entryDate,
            age:this.searchForm.age
        }}).then((resp)=>{
          if(resp.data.code===200){
            this.students=resp.data.data;
            this.total=resp.data.total;
          }
      })
    },

    //当前页改变
    currentChange(pageNo){
      this.findAll(pageNo,this.queryDto.pageSize);
    },

    //页大小改变
    sizeChange(pageSize){
      this.findAll(this.queryDto.pageNo,pageSize)
    }
  }
}

</script>

<style scoped>
.hr0{
  height:5px;border:none;border-top:5px ridge green;
}

</style>
